class Script(object):

    START_MSG = """<b>Hai 👋 {},

["](https://t.me/potatospecs) ഞാൻ ഒരു പാവം ഫിൽറ്റർ ബോട്ട് ആണേ,എന്നെ നിങ്ങളുടെ ഗ്രൂപ്പിൽ ആഡ് ചെയ്യാൻ നോക്കി സമയം കളയണ്ട, എന്നെ [𝘾𝙄𝙉𝙀𝙈𝘼 𝙒𝙊𝙍𝙇𝘿](https://t.me/Cinema_world_officiel)ഗ്രൂപ്പിൽ മാത്രമേ ആഡ് ചെയ്യാൻ കഴിയൂ...!!!</b>
[ഞാൻ ഓപ്പൺ സോഴ്സ് ആണേ](https://github.com/IcaRuZDaedalus/Unlimited-Filter-Bot) ["](https://t.me/potatospecs)
"""


    HELP_MSG = """
നോക്കണ്ടെടാ ഉണ്ണി ഇത് നീ ഉദ്ദേശിച്ചത് അല്ല 😹 !.
Contact me to modify your bots
@potatospecs
"""


    ABOUT_MSG = """
    ഇവിടെ ഒന്നും ഇല്ല ,സമയം കളയണ്ട മിസ്റ്റർ!😹
Contact me to modify your bots
@potatospecs
"""
