# Unlimited Filter Bot

### Want a Edited Bot Like This [Contact me](https://telegram.dog/potatospecs)
>Find Me On Telegram 

> UserName [@PotatoSpecs](https://tx.me/potatospec)

## Demo [This Bot](https://telegram.dog/cc_filter_Bot)
